package com.example.hello;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(this, "VuVanSu Ph20708 CP17303", Toast.LENGTH_SHORT).show();
        txt1.findViewById(R.id.thongtin);
        txt1.setText("Thay doi noi dung");

    }
}