package com.example.lifecycleactivity;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class Demo2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo2);
    }

    @Override
    protected void onStart() {
        Log.d("onStart", "onStart: Demo2");
        super.onStart();
    }

    @Override
    protected void onPause() {
        Log.d("onPause", "onPause: Demo2");
        super.onPause();
    }

    @Override
    protected void onResume() {
        Log.d("onResume", "onResume: Demo2");
        super.onResume();
    }

    @Override
    protected void onStop() {
        Log.d("onStop", "onStop: Demo2");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d("onDestroy", "onDestroy: Demo2");
        super.onDestroy();
    }

    @Override
    protected void onRestart() {
        Log.d("onRestart", "onRestart: Demo2");
        super.onRestart();
    }
}