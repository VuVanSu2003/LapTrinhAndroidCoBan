package com.example.lifecycleactivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button btn1, btn2, btn3, btn4;
    private EditText txt1, txt2;
    private TextView kq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        kq = findViewById(R.id.kq);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinhTong();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinhHieu();
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinhTich();
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tinhThuong();
            }
        });
    }

    public void tinhTong() {
        String s1 = txt1.getText().toString();
        String s2 = txt2.getText().toString();
        double a = Double.parseDouble(s1);
        double b = Double.parseDouble(s2);
        double c = a + b;
        kq.setText("Tong la: " + String.valueOf(c));
    }

    public void tinhHieu() {
        String s1 = txt1.getText().toString();
        String s2 = txt2.getText().toString();
        double a = Double.parseDouble(s1);
        double b = Double.parseDouble(s2);
        double c = a - b;
        kq.setText("Hieu la: " + String.valueOf(c));
    }

    public void tinhTich() {
        String s1 = txt1.getText().toString();
        String s2 = txt2.getText().toString();
        double a = Double.parseDouble(s1);
        double b = Double.parseDouble(s2);
        double c = a * b;
        kq.setText("Tich la: " + String.valueOf(c));
    }

    public void tinhThuong() {
        String s1 = txt1.getText().toString();
        String s2 = txt2.getText().toString();
        double a = Double.parseDouble(s1);
        double b = Double.parseDouble(s2);
        double c = a / b;
        kq.setText("Thuong la: " + String.valueOf(c));
    }


    @Override
    protected void onStart() {
        Log.i("test", "Gọi hàm onStart");
        super.onStart();
    }

    @Override
    protected void onRestart() {
        Log.i("test", "Gọi hàm onRestart");

        super.onRestart();
    }

    @Override
    protected void onStop() {
        Log.i("test", "Gọi hàm onStop");

        super.onStop();
    }

    @Override
    protected void onResume() {
        Log.i("test", "Gọi hàm onResume");

        super.onResume();

    }

    @Override
    protected void onPause() {
        Log.i("test", "Gọi hàm onPause");

        super.onPause();

    }

    @Override
    protected void onDestroy() {
        Log.i("test", "Gọi hàm onDestroy");

        super.onDestroy();
    }

}

